import { Employee } from './employee.model';
import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Benefit } from './benefit.model';
import { AddEditEmployeeComponent } from './../add-edit-employee/add-edit-employee.component'
import { EmployeeBenefit } from './employee-benefit.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeBenefitsService {
  readonly rootURL = 'https://localhost:44335/api';         //the url of the api
  list: Employee[];
  employee: Employee;
  benefitsList: Benefit[];
  employeeBenefitsList: EmployeeBenefit[];        
  previousBenefits: number[] = [];            //has the ids of the benefits that an employee has when editting him/her
  checkedBenefits: number[] = [];       //has the ids of benefits that are checked during the process of adding or editting an employee 
  formData: Employee;                   //employee data to be inserted or updated

  constructor(private http: HttpClient) { }

  postEmployee() {
    return this.http.post(this.rootURL + '/Employees', this.formData);                     //inserts an employee to database
  }

  putEmployee() {
    return this.http.put(this.rootURL + '/Employees/' + this.formData.EmployeeId, this.formData);     //updates an employee in the database
  }
  deleteEmployee(id) {
    return this.http.delete(this.rootURL + '/Employees/' + id);                //deletes employee from database
  }

  getEmployees(){
    this.http.get(this.rootURL + '/Employees')
      .toPromise()
      .then(res => this.list = res as Employee[]);                 //gets all employees from database and inserts them in list
  }

  getBenefits() {
    this.http.get(this.rootURL + '/Benefits')
      .toPromise()
      .then(res => this.benefitsList = res as Benefit[]);          //gets all benefits from database and inserts them in benefitsList
  }

  getEmployeeBenefits() {
    this.http.get(this.rootURL + '/EmployeeBenefits')
      .toPromise()
      .then(res => this.employeeBenefitsList = res as EmployeeBenefit[]);       //get all employee-benefit relations and and inserts them in employeeBenefitsList
  }

  postEmployeeBenefit(empbenefit: EmployeeBenefit) {
    return this.http.post(this.rootURL + '/EmployeeBenefits', empbenefit);      //inserts an employee-benefit relation into the database
  }

  deleteEmployeeBenefit(id){
    return this.http.delete(this.rootURL + '/EmployeeBenefits/' + id);           // //deletes an employee-benefit relation from the database
  }
}
