export class Benefit {
  BenefitId: number;
  Name: string;
}
