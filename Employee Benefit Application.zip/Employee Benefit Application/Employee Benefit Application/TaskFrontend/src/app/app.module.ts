import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { RouterModule } from '@angular/router';
import { HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { DatePipe } from '@angular/common';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AddEditEmployeeComponent } from './add-edit-employee/add-edit-employee.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { EmployeeBenefitsService } from './shared/employee-benefits.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddEditEmployeeComponent,
    ListEmployeesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'add-edit', component: AddEditEmployeeComponent },
      { path: 'list', component: ListEmployeesComponent },
    ])
  ],
  providers: [EmployeeBenefitsService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
