﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class SystemConfig
    {
        [Key]
        public int SystemConfigId { get; set; }

        [Column(TypeName = "varchar(MAX)")]
        public string ConfigData { get; set; }
    }
}
