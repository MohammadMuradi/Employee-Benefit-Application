﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class EmployeeBenefit
    {
        [Key]
        public int EmployeeBenefitId { get; set; }

        [Required]
        [Column(TypeName = "int")]
        [ForeignKey("Employee")]
        public int EmployeeId { get; set; }

        [Required]
        [Column(TypeName = "int")]
        [ForeignKey("Benefit")]
        public int BenefitId { get; set; }
    }
}
