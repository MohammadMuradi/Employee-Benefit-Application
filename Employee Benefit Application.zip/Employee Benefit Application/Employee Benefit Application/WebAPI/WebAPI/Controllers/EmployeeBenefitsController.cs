﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeBenefitsController : ControllerBase
    {
        private readonly EmployeeBenefitContext _context;

        public EmployeeBenefitsController(EmployeeBenefitContext context)
        {
            _context = context;
        }

        // GET: api/EmployeeBenefits
        [HttpGet]
        public IEnumerable<EmployeeBenefit> GetEmployeeBenefit()
        {
            return _context.EmployeeBenefit;
        }

        // GET: api/EmployeeBenefits/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeeBenefit([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var employeeBenefit = await _context.EmployeeBenefit.FindAsync(id);

            if (employeeBenefit == null)
            {
                return NotFound();
            }

            return Ok(employeeBenefit);
        }

        // PUT: api/EmployeeBenefits/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployeeBenefit([FromRoute] int id, [FromBody] EmployeeBenefit employeeBenefit)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != employeeBenefit.EmployeeBenefitId)
            {
                return BadRequest();
            }

            _context.Entry(employeeBenefit).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeBenefitExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EmployeeBenefits
        [HttpPost]
        public async Task<IActionResult> PostEmployeeBenefit([FromBody] EmployeeBenefit employeeBenefit)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.EmployeeBenefit.Add(employeeBenefit);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEmployeeBenefit", new { id = employeeBenefit.EmployeeBenefitId }, employeeBenefit);
        }

        // DELETE: api/EmployeeBenefits/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployeeBenefit([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var employeeBenefit = await _context.EmployeeBenefit.FindAsync(id);
            if (employeeBenefit == null)
            {
                return NotFound();
            }

            _context.EmployeeBenefit.Remove(employeeBenefit);
            await _context.SaveChangesAsync();

            return Ok(employeeBenefit);
        }

        private bool EmployeeBenefitExists(int id)
        {
            return _context.EmployeeBenefit.Any(e => e.EmployeeBenefitId == id);
        }
    }
}